# MediScan AI: Mobile Opto-Inertial Hardware & Multi-Agent Drug Repurposing Platform

> **Hardware-Coupled Pharmaceutical Specimen Verification & Multi-Agent Therapeutic Intelligence Engine**
>
> **Submitted By:** Sanjivani More (2124UCSF1115), Tanushri Khurud (2124UCSF1151), Dhanshri Nehe (2124UCSF1127)  
> **Guided By:** Prof. Aparupa Chakraborty  
> **Institution:** Department of Cyber Security, School of Engineering & Technology, Sanjivani University, Kopargaon

---

## 1. Overview & Hardware-Software Architecture

**MediScan AI (Hardware + Multi-Agent Patent Edition)** integrates a **Mobile Opto-Inertial Hardware Sensor Unit (MHOI-100)** directly with a parallel **Multi-Agent Biomedical Repurposing Engine**:

1. **Mobile Hardware Specimen Acquisition & Physical Assay (`backend/app/hardware/` & `HardwareScannerPage.tsx`)**:
   - **3-Axis MEMS Accelerometer & Gyroscope Stabilization Gate**: Samples real-time linear acceleration $(a_x, a_y, a_z)$ and angular velocity $(\omega_x, \omega_y, \omega_z)$ via the smartphone's hardware IMU (`DeviceMotionEvent`). Blocks optical capture until RMS acceleration jitter $J_{\text{acc}} \le 0.35\text{ m/s}^2$ and planar tilt angle $\theta \le 18.0^\circ$.
   - **CMOS Macro Image Sensor & Programmable LED Flash Strobe (`ImageCapture` / `MediaStreamTrack` Torch API)**: Captures macro surface reflectance under calibrated solid-state LED illumination and transforms sRGB pixel vectors into **CIE 1976 $L^*a^*b^*$ perceptual color space**.
   - **Colorimetric Deviation ($\Delta E_{ab}^*$) & Specular Gloss Assay ($G_{\text{spec}}$)**: Authenticates tablet film-coating integrity, aspect ratio, circularity, and debossed imprint codes against reference pharmacopeial profiles, producing a **Hardware Formulation Integrity Score ($0\text{--}100$)** and a **SHA-256 Hardware Telemetry Attestation Hash**.
2. **Parallel Multi-Agent Repurposing Engine (`backend/app/agents/`)**:
   - Once the physical specimen is authenticated by the Mobile Hardware Sensor Unit, the **Master Orchestrator Agent** dispatches 4 specialized research agents concurrently via `asyncio.gather`:
     - **Clinical Agent** (`ClinicalTrials.gov API v2` — 40% weight)
     - **Patent Agent** (`USPTO / PatentsView` — 30% weight)
     - **Literature Agent** (`NCBI PubMed / Europe PMC` — 20% weight)
     - **Market & Regulatory Agent** (`OpenFDA / Orange Book` — 10% weight)
   - Coupled with the **Hardware Sensor Agent**, the platform computes composite scores, SHAP-inspired feature explanations, 15-feature Random Forest probability estimates, and exports publication-grade **PDF, HTML, JSON, and CSV** dossiers.

---

## 2. How to Run on Windows & VS Code (Step-by-Step)

### Prerequisites on Windows
1. **Python 3.10 or 3.11+** installed (with `"Add Python to PATH"` checked during installation).
2. **Node.js 18+ (LTS)** installed from [https://nodejs.org/](https://nodejs.org/).
3. **Visual Studio Code (VS Code)** installed.

### Method A: One-Click Windows Batch Launcher (Fastest)
1. Extract `MEDISCAN_AI_HARDWARE_SOFTWARE_PROJECT.zip` to your Desktop or Documents folder.
2. Open the extracted `MEDISCAN-AI-` folder and double-click **`START_MEDISCAN_WINDOWS.bat`**.
3. The script automatically creates `.venv`, installs Python & Node dependencies, launches the FastAPI Backend on `http://localhost:8000`, and launches the React Frontend on `http://localhost:5173`.

### Method B: Running Inside VS Code Integrated Terminal
1. Open **VS Code** -> **File** -> **Open Folder...** -> Select the `MEDISCAN-AI-` folder.
2. Open **Terminal 1 (Backend)** (`Ctrl + Shift + \``):
   ```powershell
   python -m venv .venv
   .\.venv\Scripts\activate
   pip install -r backend\requirements.txt
   python -m uvicorn backend.app.main:app --host 0.0.0.0 --port 8000 --reload
   ```
3. Open **Terminal 2 (Frontend)** (click the `+` icon in the VS Code terminal panel):
   ```powershell
   cd frontend
   npm install
   npm run dev -- --host 0.0.0.0
   ```
4. Open your browser at **[http://localhost:5173](http://localhost:5173)** (or open `http://<Your-Laptop-Wi-Fi-IP>:5173` on your **Smartphone browser** connected to the same Wi-Fi network to use your phone's real camera, LED flash torch, and MEMS accelerometer/gyroscope!).

### Default Login Accounts
| Role | Email | Password |
|---|---|---|
| **Administrator** | `admin@mediscan.ai` | `Admin12345!` |
| **Researcher** | `researcher@mediscan.ai` | `Researcher12345!` |

### Running the Automated Test Suite (Hardware + Software)
```powershell
.\.venv\Scripts\activate
pytest tests/ -v
```
