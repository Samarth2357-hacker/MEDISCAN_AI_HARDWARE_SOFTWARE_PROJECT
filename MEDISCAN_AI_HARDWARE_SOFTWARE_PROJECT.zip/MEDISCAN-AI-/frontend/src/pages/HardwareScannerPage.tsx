import React, { useState, useEffect, useRef } from 'react';
import {
  Camera,
  Flashlight,
  Activity,
  ShieldCheck,
  Cpu,
  Smartphone,
  Play,
  RefreshCw,
  CheckCircle2,
  AlertTriangle,
  Sparkles,
  Upload,
  Sliders,
  Hash
} from 'lucide-react';
import { api } from '../api/client';

interface HardwareScannerPageProps {
  onNavigate: (view: string, id?: string) => void;
}

interface PresetDrug {
  key: string;
  name: string;
  imprint: string;
  dosage: string;
  barcode: string;
  rgb: { r: number; g: number; b: number };
  gloss: number;
  aspect: number;
  circ: number;
  coating: string;
}

const HARDWARE_PRESETS: PresetDrug[] = [
  {
    key: 'metformin',
    name: 'Metformin',
    imprint: 'MET 500',
    dosage: '500 mg Film-Coated Biconvex Tablet',
    barcode: '00087-6060-01',
    rgb: { r: 241, g: 242, b: 238 },
    gloss: 0.68,
    aspect: 1.85,
    circ: 0.78,
    coating: 'Hydrophilic HPMC Polymer Film Coating'
  },
  {
    key: 'aspirin',
    name: 'Aspirin',
    imprint: 'BAYER 325',
    dosage: '325 mg Uncoated Compressed Round Tablet',
    barcode: '00280-1000-01',
    rgb: { r: 246, g: 246, b: 243 },
    gloss: 0.34,
    aspect: 1.02,
    circ: 0.96,
    coating: 'Uncoated Compressed Crystalline Matrix'
  },
  {
    key: 'atorvastatin',
    name: 'Atorvastatin',
    imprint: 'PD 156 / 20',
    dosage: '20 mg Elliptical Film-Coated Tablet',
    barcode: '00071-0156-23',
    rgb: { r: 239, g: 239, b: 233 },
    gloss: 0.74,
    aspect: 1.92,
    circ: 0.74,
    coating: 'Opadry II White Film Coating (CaCO3 Stabilized)'
  },
  {
    key: 'losartan',
    name: 'Losartan',
    imprint: '952 / LOS 50',
    dosage: '50 mg Teardrop Film-Coated Tablet',
    barcode: '00006-0952-31',
    rgb: { r: 195, g: 226, b: 182 },
    gloss: 0.71,
    aspect: 1.48,
    circ: 0.83,
    coating: 'HPC / Titanium Dioxide / Carnauba Wax Polish'
  },
  {
    key: 'rapamycin',
    name: 'Sirolimus',
    imprint: 'RAPAMUNE 1',
    dosage: '1 mg Triangular Sugar-Coated Tablet',
    barcode: '00008-1030-04',
    rgb: { r: 234, g: 218, b: 188 },
    gloss: 0.81,
    aspect: 1.15,
    circ: 0.81,
    coating: 'NanoCrystal Colloidal Dispersion Solid Coat'
  }
];

export const HardwareScannerPage: React.FC<HardwareScannerPageProps> = ({ onNavigate }) => {
  const [selectedPreset, setSelectedPreset] = useState<PresetDrug>(HARDWARE_PRESETS[0]);
  const [cameraActive, setCameraActive] = useState(false);
  const [torchEnabled, setTorchEnabled] = useState(true);
  const [imuLiveActive, setImuLiveActive] = useState(false);

  // 3-Axis MEMS Accelerometer & Gyroscope State
  const [accel, setAccel] = useState({ x: 0.04, y: -0.03, z: 9.80 });
  const [gyro, setGyro] = useState({ alpha: 0.01, beta: 0.01, gamma: 0.01 });
  const [imuJitter, setImuJitter] = useState(0.05);
  const [tiltAngle, setTiltAngle] = useState(2.4);

  // CMOS Optical & Morphological State
  const [rgb, setRgb] = useState(HARDWARE_PRESETS[0].rgb);
  const [gloss, setGloss] = useState(HARDWARE_PRESETS[0].gloss);
  const [sharpness, setSharpness] = useState(86.4);
  const [imprintCode, setImprintCode] = useState(HARDWARE_PRESETS[0].imprint);
  const [barcodeData, setBarcodeData] = useState(HARDWARE_PRESETS[0].barcode);
  const [capturedFrame, setCapturedFrame] = useState<string | null>(null);

  // Hardware Assay Output
  const [assayResult, setAssayResult] = useState<any | null>(null);
  const [scanning, setScanning] = useState(false);
  const [launching, setLaunching] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const videoRef = useRef<HTMLVideoElement | null>(null);
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const streamRef = useRef<MediaStream | null>(null);

  // Subscribe to Smartphone Hardware MEMS Accelerometer & Gyroscope (HTML5 DeviceMotion / Orientation API)
  useEffect(() => {
    const handleMotion = (event: DeviceMotionEvent) => {
      if (event.accelerationIncludingGravity) {
        const ax = event.accelerationIncludingGravity.x || 0;
        const ay = event.accelerationIncludingGravity.y || 0;
        const az = event.accelerationIncludingGravity.z || 9.8;
        setImuLiveActive(true);
        setAccel({
          x: Number(ax.toFixed(3)),
          y: Number(ay.toFixed(3)),
          z: Number(az.toFixed(3))
        });
        const gNorm = Math.sqrt(ax * ax + ay * ay + az * az) || 9.81;
        const jitter = Math.min(1.5, Math.abs(gNorm - 9.81) * 0.35 + Math.sqrt(ax * ax + ay * ay) * 0.04);
        setImuJitter(Number(jitter.toFixed(3)));
        const tilt = Math.acos(Math.min(1, Math.abs(az) / gNorm)) * (180 / Math.PI);
        setTiltAngle(Number(tilt.toFixed(1)));
      }
      if (event.rotationRate) {
        setGyro({
          alpha: Number(((event.rotationRate.alpha || 0) * 0.01745).toFixed(3)),
          beta: Number(((event.rotationRate.beta || 0) * 0.01745).toFixed(3)),
          gamma: Number(((event.rotationRate.gamma || 0) * 0.01745).toFixed(3))
        });
      }
    };

    window.addEventListener('devicemotion', handleMotion);
    return () => {
      window.removeEventListener('devicemotion', handleMotion);
      stopCamera();
    };
  }, []);

  const handlePresetChange = (preset: PresetDrug) => {
    setSelectedPreset(preset);
    setRgb(preset.rgb);
    setGloss(preset.gloss);
    setImprintCode(preset.imprint);
    setBarcodeData(preset.barcode);
    setAssayResult(null);
  };

  const startCamera = async () => {
    setError(null);
    try {
      const stream = await navigator.mediaDevices.getUserMedia({
        video: {
          facingMode: { ideal: 'environment' },
          width: { ideal: 1920 },
          height: { ideal: 1080 }
        },
        audio: false
      });
      streamRef.current = stream;
      if (videoRef.current) {
        videoRef.current.srcObject = stream;
      }
      setCameraActive(true);

      // Attempt to activate Smartphone Hardware LED Flash Torch if supported
      const track = stream.getVideoTracks()[0];
      if (track && torchEnabled) {
        try {
          await track.applyConstraints({ advanced: [{ torch: true } as any] });
        } catch {
          // Hardware torch constraint optional on desktop webcams
        }
      }
    } catch (err: any) {
      setError(
        'Direct camera stream unavailable on this host. Using Interactive Mobile Opto-Inertial Hardware Telemetry Bench.'
      );
    }
  };

  const stopCamera = () => {
    if (streamRef.current) {
      streamRef.current.getTracks().forEach((t) => t.stop());
      streamRef.current = null;
    }
    setCameraActive(false);
  };

  const toggleHardwareTorch = async () => {
    const nextState = !torchEnabled;
    setTorchEnabled(nextState);
    if (streamRef.current) {
      const track = streamRef.current.getVideoTracks()[0];
      if (track) {
        try {
          await track.applyConstraints({ advanced: [{ torch: nextState } as any] });
        } catch {
          // Ignore if desktop webcam lacks LED torch
        }
      }
    }
  };

  const captureLiveFrameOptics = (): string | null => {
    if (!videoRef.current || !canvasRef.current || !cameraActive) return capturedFrame;
    const video = videoRef.current;
    const canvas = canvasRef.current;
    canvas.width = video.videoWidth || 640;
    canvas.height = video.videoHeight || 480;
    const ctx = canvas.getContext('2d');
    if (!ctx) return null;
    ctx.drawImage(video, 0, 0, canvas.width, canvas.height);

    // Sample central 200x200 ROI for real-time RGB colorimetric reflectance
    const rx = Math.max(0, Math.floor(canvas.width / 2 - 100));
    const ry = Math.max(0, Math.floor(canvas.height / 2 - 100));
    const imgData = ctx.getImageData(rx, ry, 200, 200).data;
    let rSum = 0, gSum = 0, bSum = 0, count = 0;
    for (let i = 0; i < imgData.length; i += 4) {
      rSum += imgData[i];
      gSum += imgData[i + 1];
      bSum += imgData[i + 2];
      count++;
    }
    if (count > 0) {
      setRgb({
        r: Math.round(rSum / count),
        g: Math.round(gSum / count),
        b: Math.round(bSum / count)
      });
    }
    const dataUrl = canvas.toDataURL('image/jpeg', 0.85);
    setCapturedFrame(dataUrl);
    return dataUrl;
  };

  const handleImageUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = () => {
      if (typeof reader.result === 'string') {
        setCapturedFrame(reader.result);
      }
    };
    reader.readAsDataURL(file);
  };

  const runHardwareScanOnly = async () => {
    setError(null);
    setScanning(true);
    try {
      const frameData = captureLiveFrameOptics();
      const res = await api.hardware.scan({
        drug_name: selectedPreset.name,
        imprint_code: imprintCode,
        barcode_data: barcodeData,
        torch_enabled: torchEnabled,
        accel_x: accel.x,
        accel_y: accel.y,
        accel_z: accel.z,
        gyro_alpha: gyro.alpha,
        gyro_beta: gyro.beta,
        gyro_gamma: gyro.gamma,
        imu_jitter_ms2: imuJitter,
        image_base64: frameData || undefined,
        rgb_r: rgb.r,
        rgb_g: rgb.g,
        rgb_b: rgb.b,
        specular_gloss_index: gloss,
        laplacian_sharpness: sharpness,
        aspect_ratio: selectedPreset.aspect,
        circularity: selectedPreset.circ
      });
      setAssayResult(res);
    } catch (err: any) {
      setError(err.message || 'Hardware sensor assay failed.');
    } finally {
      setScanning(false);
    }
  };

  const runHardwareAndLaunchResearch = async () => {
    setError(null);
    setLaunching(true);
    try {
      const frameData = captureLiveFrameOptics();
      const res = await api.hardware.scanAndResearch({
        drug_name: selectedPreset.name,
        imprint_code: imprintCode,
        barcode_data: barcodeData,
        torch_enabled: torchEnabled,
        accel_x: accel.x,
        accel_y: accel.y,
        accel_z: accel.z,
        gyro_alpha: gyro.alpha,
        gyro_beta: gyro.beta,
        gyro_gamma: gyro.gamma,
        imu_jitter_ms2: imuJitter,
        image_base64: frameData || undefined,
        rgb_r: rgb.r,
        rgb_g: rgb.g,
        rgb_b: rgb.b,
        specular_gloss_index: gloss,
        laplacian_sharpness: sharpness,
        aspect_ratio: selectedPreset.aspect,
        circularity: selectedPreset.circ
      });
      setAssayResult(res);
      if (res.query_id) {
        onNavigate('live-analysis', res.query_id);
      }
    } catch (err: any) {
      setError(err.message || 'Failed to launch hardware-coupled repurposing analysis.');
      setLaunching(false);
    }
  };

  const imuGatePassed = imuJitter <= 0.35 && tiltAngle <= 18.0;

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-6">
      {/* Header Banner */}
      <div className="bg-slate-900 text-white rounded-2xl p-6 sm:p-8 border border-slate-800 shadow-lg flex flex-col lg:flex-row lg:items-center lg:justify-between gap-6">
        <div className="space-y-2">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-teal-500/20 border border-teal-500/30 text-teal-300 text-xs font-semibold">
            <Smartphone className="w-3.5 h-3.5" />
            <span>PATENT HARDWARE MODULE • MOBILE OPTO-INERTIAL SENSOR UNIT (MHOI-100)</span>
          </div>
          <h1 className="text-2xl sm:text-3xl font-bold tracking-tight">
            Smartphone Optical-Inertial Specimen Assay & Multi-Agent Trigger
          </h1>
          <p className="text-xs sm:text-sm text-slate-300 max-w-3xl">
            Couples the smartphone&apos;s physical <strong>CMOS Macro Image Sensor</strong>,{' '}
            <strong>Programmable Solid-State LED Torch Strobe</strong>, and{' '}
            <strong>3-Axis MEMS Accelerometer/Gyroscope Stability Gate</strong> to authenticate pharmaceutical
            specimens in CIE L*a*b* color space before dispatching the parallel AI repurposing agents.
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-3">
          {!cameraActive ? (
            <button
              type="button"
              onClick={startCamera}
              className="px-4 py-2.5 bg-teal-600 hover:bg-teal-500 text-white text-xs font-bold rounded-xl flex items-center gap-2 shadow-sm transition-colors"
            >
              <Camera className="w-4 h-4" />
              Activate Mobile Camera & IMU
            </button>
          ) : (
            <button
              type="button"
              onClick={stopCamera}
              className="px-4 py-2.5 bg-rose-600 hover:bg-rose-500 text-white text-xs font-bold rounded-xl flex items-center gap-2 shadow-sm transition-colors"
            >
              <RefreshCw className="w-4 h-4" />
              Stop Camera Stream
            </button>
          )}

          <button
            type="button"
            onClick={toggleHardwareTorch}
            className={`px-4 py-2.5 text-xs font-bold rounded-xl flex items-center gap-2 border transition-colors ${
              torchEnabled
                ? 'bg-amber-500/20 border-amber-400 text-amber-300'
                : 'bg-slate-800 border-slate-700 text-slate-400'
            }`}
          >
            <Flashlight className="w-4 h-4" />
            LED Torch Strobe: {torchEnabled ? 'ON (D65 Calibrated)' : 'OFF'}
          </button>
        </div>
      </div>

      {error && (
        <div className="p-4 bg-amber-50 border border-amber-200 text-amber-900 rounded-xl text-xs flex items-center gap-2.5">
          <AlertTriangle className="w-4 h-4 text-amber-600 flex-shrink-0" />
          <span>{error}</span>
        </div>
      )}

      {/* Main 2-Column Hardware Workbench */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Left Column: Optical CMOS Viewport + Specimen Selector (7 cols) */}
        <div className="lg:col-span-7 space-y-6">
          {/* Specimen Selector Bar */}
          <div className="bg-white rounded-2xl border border-slate-200 p-5 shadow-sm space-y-4">
            <div className="flex items-center justify-between">
              <span className="text-xs font-bold uppercase tracking-wider text-slate-700 flex items-center gap-1.5">
                <Cpu className="w-4 h-4 text-teal-600" />
                1. Physical Pharmaceutical Specimen Calibration Target
              </span>
              <span className="text-[11px] text-slate-400">
                Select physical tablet specimen or scan live
              </span>
            </div>

            <div className="grid grid-cols-2 sm:grid-cols-5 gap-2.5">
              {HARDWARE_PRESETS.map((p) => (
                <button
                  key={p.key}
                  type="button"
                  onClick={() => handlePresetChange(p)}
                  className={`p-3 rounded-xl border text-left transition-all ${
                    selectedPreset.key === p.key
                      ? 'bg-teal-50/70 border-teal-500 ring-2 ring-teal-500/20'
                      : 'bg-slate-50 border-slate-200 hover:bg-slate-100'
                  }`}
                >
                  <div className="flex items-center justify-between mb-1">
                    <span className="font-bold text-xs text-slate-900">{p.name}</span>
                    <span
                      className="w-3.5 h-3.5 rounded-full border border-slate-300"
                      style={{ backgroundColor: `rgb(${p.rgb.r}, ${p.rgb.g}, ${p.rgb.b})` }}
                    />
                  </div>
                  <span className="block font-mono text-[10px] text-teal-700">{p.imprint}</span>
                </button>
              ))}
            </div>

            {/* Optical Viewport */}
            <div className="relative bg-slate-950 rounded-xl overflow-hidden border border-slate-800 aspect-video flex items-center justify-center">
              <video
                ref={videoRef}
                autoPlay
                playsInline
                muted
                className={`w-full h-full object-cover ${cameraActive ? 'block' : 'hidden'}`}
              />
              <canvas ref={canvasRef} className="hidden" />

              {!cameraActive && (
                <div className="text-center p-6 space-y-3">
                  <div
                    className="w-24 h-14 mx-auto rounded-full border-4 border-teal-400/80 shadow-inner flex items-center justify-center font-mono text-xs font-bold text-slate-800"
                    style={{
                      backgroundColor: `rgb(${rgb.r}, ${rgb.g}, ${rgb.b})`,
                      boxShadow: torchEnabled ? '0 0 35px rgba(251, 191, 36, 0.35)' : 'none'
                    }}
                  >
                    {imprintCode}
                  </div>
                  <p className="text-xs font-semibold text-slate-200">
                    Macro ROI Target: {selectedPreset.name} ({selectedPreset.dosage})
                  </p>
                  <p className="text-[11px] text-slate-400 max-w-md mx-auto">
                    {selectedPreset.coating} • NDC Barcode: {barcodeData}
                  </p>
                </div>
              )}

              {/* HUD Overlay Crosshairs */}
              <div className="absolute inset-0 pointer-events-none flex items-center justify-center">
                <div
                  className={`w-48 h-32 rounded-2xl border-2 transition-colors ${
                    imuGatePassed ? 'border-emerald-400/80' : 'border-rose-500/80'
                  }`}
                />
              </div>

              <div className="absolute top-3 left-3 right-3 flex items-center justify-between text-[11px] font-mono">
                <span className="px-2.5 py-1 rounded bg-slate-900/80 text-teal-300 border border-slate-700">
                  RGB({rgb.r}, {rgb.g}, {rgb.b}) • Gloss: {gloss.toFixed(2)}
                </span>
                <span
                  className={`px-2.5 py-1 rounded font-bold border ${
                    imuGatePassed
                      ? 'bg-emerald-950/90 text-emerald-300 border-emerald-700'
                      : 'bg-rose-950/90 text-rose-300 border-rose-700'
                  }`}
                >
                  {imuGatePassed ? 'IMU GATE: LOCKED (STABLE)' : 'IMU GATE: MOTION BLOCKED'}
                </span>
              </div>
            </div>

            {/* Optical Frame Upload + Imprint Inputs */}
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 pt-2">
              <div>
                <label className="block text-[10px] font-bold uppercase text-slate-500 mb-1">
                  Detected Imprint Code
                </label>
                <input
                  type="text"
                  value={imprintCode}
                  onChange={(e) => setImprintCode(e.target.value)}
                  className="w-full px-3 py-2 text-xs font-mono border border-slate-200 rounded-lg"
                />
              </div>
              <div>
                <label className="block text-[10px] font-bold uppercase text-slate-500 mb-1">
                  GS1 / NDC Barcode
                </label>
                <input
                  type="text"
                  value={barcodeData}
                  onChange={(e) => setBarcodeData(e.target.value)}
                  className="w-full px-3 py-2 text-xs font-mono border border-slate-200 rounded-lg"
                />
              </div>
              <div>
                <label className="block text-[10px] font-bold uppercase text-slate-500 mb-1">
                  Upload Macro Pill Image
                </label>
                <label className="w-full px-3 py-2 text-xs border border-slate-200 rounded-lg bg-slate-50 hover:bg-slate-100 cursor-pointer flex items-center justify-center gap-1.5 text-slate-700 font-medium">
                  <Upload className="w-3.5 h-3.5 text-teal-600" />
                  <span>Choose Image...</span>
                  <input type="file" accept="image/*" onChange={handleImageUpload} className="hidden" />
                </label>
              </div>
            </div>
          </div>
        </div>

        {/* Right Column: Live 3-Axis MEMS IMU & Colorimetric Telemetry Controls (5 cols) */}
        <div className="lg:col-span-5 space-y-6">
          <div className="bg-white rounded-2xl border border-slate-200 p-5 shadow-sm space-y-4">
            <div className="flex items-center justify-between">
              <span className="text-xs font-bold uppercase tracking-wider text-slate-700 flex items-center gap-1.5">
                <Sliders className="w-4 h-4 text-teal-600" />
                2. 3-Axis MEMS Inertial & Optical Sensor Telemetry
              </span>
              <span className="text-[10px] px-2 py-0.5 rounded bg-slate-100 text-slate-600 font-mono">
                {imuLiveActive ? 'Hardware IMU Live' : 'Interactive Bench'}
              </span>
            </div>

            {/* IMU Sliders for Testing Hardware Gate on Windows / VSCode */}
            <div className="space-y-3 bg-slate-50 p-3.5 rounded-xl border border-slate-200/80 text-xs">
              <div>
                <div className="flex justify-between font-medium mb-1">
                  <span>MEMS Accelerometer RMS Jitter (m/s²)</span>
                  <span className={`font-mono font-bold ${imuJitter <= 0.35 ? 'text-emerald-600' : 'text-rose-600'}`}>
                    {imuJitter.toFixed(3)} m/s² (Max: 0.35)
                  </span>
                </div>
                <input
                  type="range"
                  min="0.01"
                  max="0.80"
                  step="0.01"
                  value={imuJitter}
                  onChange={(e) => setImuJitter(parseFloat(e.target.value))}
                  className="w-full accent-teal-600"
                />
              </div>

              <div>
                <div className="flex justify-between font-medium mb-1">
                  <span>Optical Planar Tilt Angle θ (degrees)</span>
                  <span className={`font-mono font-bold ${tiltAngle <= 18.0 ? 'text-emerald-600' : 'text-rose-600'}`}>
                    {tiltAngle.toFixed(1)}° (Max: 18.0°)
                  </span>
                </div>
                <input
                  type="range"
                  min="0.0"
                  max="35.0"
                  step="0.5"
                  value={tiltAngle}
                  onChange={(e) => setTiltAngle(parseFloat(e.target.value))}
                  className="w-full accent-teal-600"
                />
              </div>

              <div>
                <div className="flex justify-between font-medium mb-1">
                  <span>LED Torch Specular Gloss Index (G_spec)</span>
                  <span className="font-mono font-bold text-teal-700">{gloss.toFixed(2)}</span>
                </div>
                <input
                  type="range"
                  min="0.20"
                  max="0.95"
                  step="0.01"
                  value={gloss}
                  onChange={(e) => setGloss(parseFloat(e.target.value))}
                  className="w-full accent-teal-600"
                />
              </div>

              <div className="grid grid-cols-3 gap-2 pt-1 font-mono text-[10px] text-slate-600">
                <div className="bg-white p-2 rounded border border-slate-200">
                  a_x: {accel.x} m/s²
                </div>
                <div className="bg-white p-2 rounded border border-slate-200">
                  a_y: {accel.y} m/s²
                </div>
                <div className="bg-white p-2 rounded border border-slate-200">
                  a_z: {accel.z} m/s²
                </div>
              </div>
            </div>

            {/* Action Buttons */}
            <div className="space-y-2.5 pt-2">
              <button
                type="button"
                disabled={scanning || launching}
                onClick={runHardwareScanOnly}
                className="w-full py-2.5 px-4 bg-slate-900 hover:bg-slate-800 text-white font-bold text-xs rounded-xl shadow-sm transition-colors flex items-center justify-center gap-2"
              >
                <ShieldCheck className="w-4 h-4 text-teal-400" />
                {scanning ? 'Running Opto-Inertial Assay...' : 'Step 1: Verify Physical Specimen (Hardware Assay)'}
              </button>

              <button
                type="button"
                disabled={scanning || launching || !imuGatePassed}
                onClick={runHardwareAndLaunchResearch}
                className="w-full py-3 px-4 bg-teal-600 hover:bg-teal-500 disabled:bg-slate-300 text-white font-bold text-xs rounded-xl shadow-md transition-colors flex items-center justify-center gap-2"
              >
                <Sparkles className="w-4 h-4" />
                {launching
                  ? 'Spawning Hardware-Coupled Multi-Agent Pipeline...'
                  : 'Step 2: Authenticate & Launch Multi-Agent Repurposing'}
              </button>
            </div>
          </div>

          {/* Hardware Assay Result Card */}
          {assayResult && (
            <div className="bg-white rounded-2xl border border-teal-300 p-5 shadow-sm space-y-3 animate-in fade-in duration-200">
              <div className="flex items-center justify-between border-b border-slate-100 pb-2.5">
                <div className="flex items-center gap-2">
                  <CheckCircle2 className="w-5 h-5 text-emerald-600" />
                  <div>
                    <h3 className="text-xs font-bold text-slate-900 uppercase">
                      Hardware Physical Assay Verified
                    </h3>
                    <p className="text-[11px] text-teal-700 font-semibold">
                      {assayResult.resolved_drug_name} (CID: {assayResult.pubchem_cid})
                    </p>
                  </div>
                </div>
                <div className="text-right">
                  <span className="text-lg font-extrabold text-slate-900">
                    {assayResult.hardware_integrity_score}/100
                  </span>
                  <span className="block text-[9px] uppercase font-bold text-emerald-600">
                    Integrity Score
                  </span>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-2 text-[11px]">
                <div className="bg-slate-50 p-2 rounded border border-slate-200">
                  <span className="text-slate-400 block text-[10px]">CIE L*a*b* Measured</span>
                  <span className="font-mono font-bold text-slate-800">
                    L*={assayResult.optical_assay.cie_lab_measured.L}, a*={assayResult.optical_assay.cie_lab_measured.a}, b*={assayResult.optical_assay.cie_lab_measured.b}
                  </span>
                </div>
                <div className="bg-slate-50 p-2 rounded border border-slate-200">
                  <span className="text-slate-400 block text-[10px]">Chromatic Deviation ΔE*ab</span>
                  <span className="font-mono font-bold text-emerald-700">
                    ΔE* = {assayResult.optical_assay.delta_e_ab} (Ref &lt; 4.5)
                  </span>
                </div>
              </div>

              <div className="bg-slate-900 text-slate-200 p-2.5 rounded-lg font-mono text-[10px] truncate flex items-center gap-1.5">
                <Hash className="w-3.5 h-3.5 text-teal-400 flex-shrink-0" />
                <span className="truncate">SHA-256: {assayResult.telemetry_hash}</span>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
