@echo off
title MediScan AI - Hardware + Multi-Agent Patent Platform Launcher
echo ============================================================================
echo   MEDISCAN AI: MOBILE OPTO-INERTIAL HARDWARE ^& MULTI-AGENT PLATFORM
echo   Sanjivani University, Kopargaon - Department of Cyber Security
echo ============================================================================
echo.

REM 1. Check Python virtual environment
if not exist ".venv\Scripts\activate.bat" (
    echo [1/4] Creating Python virtual environment (.venv)...
    python -m venv .venv
)

echo [2/4] Activating virtual environment and verifying Python packages...
call .venv\Scripts\activate.bat
pip install -r backend\requirements.txt

echo [3/4] Starting FastAPI Backend Server (Port 8000)...
start "MediScan AI Backend API (Port 8000)" cmd /k "call .venv\Scripts\activate.bat && uvicorn backend.app.main:app --host 0.0.0.0 --port 8000 --reload"

echo [4/4] Starting React + Vite Frontend Server (Port 5173)...
cd frontend
if not exist "node_modules" (
    echo Installing frontend npm packages...
    call npm install
)
start "MediScan AI Frontend UI (Port 5173)" cmd /k "npm run dev -- --host 0.0.0.0"
cd ..

echo.
echo ============================================================================
echo   MediScan AI is launching!
echo   - Frontend Web UI:       http://localhost:5173
echo   - Hardware Scanner API:  http://localhost:8000/docs
echo   - Default Admin Login:   admin@mediscan.ai / Admin12345!
echo   - Default Researcher:    researcher@mediscan.ai / Researcher12345!
echo ============================================================================
pause
