import pytest
from backend.app.hardware.sensor_engine import hardware_sensor_engine

def test_mobile_hardware_imu_stability_gate():
    # Stable phone posture
    res_stable = hardware_sensor_engine.evaluate_imu_stability(
        accel_x=0.03, accel_y=-0.02, accel_z=9.80,
        gyro_alpha=0.01, gyro_beta=0.01, gyro_gamma=0.01,
        accel_variance_ms2=0.04
    )
    assert res_stable["imu_gate_passed"] is True
    assert res_stable["imu_stability_score"] >= 85.0

    # Shaking / tilted phone posture should fail gate
    res_unstable = hardware_sensor_engine.evaluate_imu_stability(
        accel_x=4.5, accel_y=3.8, accel_z=6.2,
        gyro_alpha=0.45, gyro_beta=0.30, gyro_gamma=0.25,
        accel_variance_ms2=0.65
    )
    assert res_unstable["imu_gate_passed"] is False

def test_mobile_hardware_optical_assay_metformin():
    assay = hardware_sensor_engine.execute_hardware_assay({
        "drug_name": "Metformin",
        "imprint_code": "MET 500",
        "torch_enabled": True,
        "accel_x": 0.02,
        "accel_y": -0.01,
        "accel_z": 9.81,
        "imu_jitter_ms2": 0.04,
        "rgb_r": 241,
        "rgb_g": 242,
        "rgb_b": 238,
        "specular_gloss_index": 0.68
    })
    assert assay["resolved_drug_name"] == "Metformin"
    assert assay["pubchem_cid"] == "4091"
    assert assay["optical_assay"]["delta_e_ab"] < 2.0
    assert assay["hardware_integrity_score"] >= 90.0
    assert len(assay["telemetry_hash"]) == 64
