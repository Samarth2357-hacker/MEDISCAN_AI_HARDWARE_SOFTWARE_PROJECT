import uuid
from datetime import datetime, timezone
from typing import List, Dict, Any
from fastapi import APIRouter, Depends, BackgroundTasks, Request, HTTPException
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select, desc

from backend.app.database.session import get_db
from backend.app.models.user import User
from backend.app.models.hardware import HardwareScanLog
from backend.app.models.research import ResearchQuery, QueryStatus
from backend.app.schemas.hardware import HardwareSensorPayload, HardwareAssayResponse
from backend.app.hardware.sensor_engine import hardware_sensor_engine, PHARMACOPEIA_HARDWARE_PROFILES
from backend.app.security.rbac import get_current_active_user, record_audit_log
from backend.app.api.research import run_master_agent_background

router = APIRouter(prefix="/hardware", tags=["Mobile Hardware Sensor Module"])


@router.get("/reference-profiles")
async def get_reference_hardware_profiles(
    current_user: User = Depends(get_current_active_user)
) -> Dict[str, Any]:
    """Return reference pharmacopeial optical (CIE L*a*b*, gloss) and morphological tablet profiles."""
    return {
        "count": len(PHARMACOPEIA_HARDWARE_PROFILES),
        "profiles": PHARMACOPEIA_HARDWARE_PROFILES
    }


@router.post("/scan", response_model=HardwareAssayResponse)
async def execute_mobile_hardware_scan(
    payload: HardwareSensorPayload,
    request: Request,
    current_user: User = Depends(get_current_active_user),
    db: AsyncSession = Depends(get_db)
):
    """
    Process real-time Smartphone CMOS Optical + 3-Axis MEMS IMU Inertial Sensor telemetry,
    compute CIE L*a*b* colorimetric Delta-E*ab and specular gloss integrity, and log a
    SHA-256 hardware attestation record.
    """
    assay = hardware_sensor_engine.execute_hardware_assay(payload.model_dump())
    scan_id = str(uuid.uuid4())

    scan_log = HardwareScanLog(
        id=scan_id,
        user_id=current_user.id,
        query_id=None,
        resolved_drug_name=assay["resolved_drug_name"],
        pubchem_cid=assay["pubchem_cid"],
        chembl_id=assay["chembl_id"],
        dosage_form=assay["dosage_form"],
        detected_imprint=assay["detected_imprint"],
        ndc_barcode=assay["ndc_barcode"],
        device_model=assay["device_model"],
        camera_resolution=assay["camera_resolution"],
        torch_enabled=assay["torch_enabled"],
        imu_gate_passed=assay["imu_telemetry"]["imu_gate_passed"],
        imu_stability_score=assay["imu_telemetry"]["imu_stability_score"],
        imu_jitter_ms2=assay["imu_telemetry"]["imu_jitter_ms2"],
        gyro_rms_rads=assay["imu_telemetry"]["gyro_rms_rads"],
        tilt_angle_deg=assay["imu_telemetry"]["tilt_angle_deg"],
        cie_l=assay["optical_assay"]["cie_lab_measured"]["L"],
        cie_a=assay["optical_assay"]["cie_lab_measured"]["a"],
        cie_b=assay["optical_assay"]["cie_lab_measured"]["b"],
        delta_e_ab=assay["optical_assay"]["delta_e_ab"],
        specular_gloss_index=assay["optical_assay"]["specular_gloss_index"],
        laplacian_sharpness=assay["optical_assay"]["laplacian_sharpness"],
        aspect_ratio=assay["optical_assay"]["aspect_ratio"],
        circularity=assay["optical_assay"]["circularity"],
        hardware_integrity_score=assay["hardware_integrity_score"],
        authenticity_status=assay["authenticity_status"],
        telemetry_hash=assay["telemetry_hash"],
        full_telemetry_json=assay,
        execution_time_ms=assay["execution_time_ms"]
    )
    db.add(scan_log)
    await db.commit()
    await db.refresh(scan_log)

    client_ip = request.client.host if request.client else None
    await record_audit_log(
        db=db,
        user_id=current_user.id,
        action="HARDWARE_OPTO_INERTIAL_SCAN",
        resource_type="HARDWARE_SCAN",
        resource_id=scan_id,
        ip_address=client_ip,
        details={
            "resolved_drug_name": assay["resolved_drug_name"],
            "hardware_integrity_score": assay["hardware_integrity_score"],
            "telemetry_hash": assay["telemetry_hash"]
        }
    )

    return HardwareAssayResponse(
        scan_id=scan_id,
        query_id=None,
        created_at=scan_log.created_at,
        **assay
    )


@router.post("/scan-and-research", response_model=HardwareAssayResponse, status_code=202)
async def execute_hardware_scan_and_launch_research(
    payload: HardwareSensorPayload,
    background_tasks: BackgroundTasks,
    request: Request,
    current_user: User = Depends(get_current_active_user),
    db: AsyncSession = Depends(get_db)
):
    """
    End-to-End Hardware-to-Software Patent Workflow:
    1. Acquires physical specimen via Mobile CMOS Optical & 3-Axis MEMS Inertial Sensor Gate.
    2. Verifies physical tablet coating reflectance (CIE L*a*b* Delta-E*ab) & morphology.
    3. Generates cryptographic SHA-256 Hardware Telemetry Attestation Hash.
    4. Automatically dispatches the Master Orchestrator Agent and 4 parallel AI Agents
       (Clinical, Literature, Patent, Market) coupled with the Hardware Sensor Agent.
    """
    assay = hardware_sensor_engine.execute_hardware_assay(payload.model_dump())
    scan_id = str(uuid.uuid4())
    query_id = str(uuid.uuid4())

    # Create ResearchQuery linked to physical specimen scan
    hw_question = (
        f"{payload.research_question or 'Investigate therapeutic repurposing indications.'} "
        f"[Hardware Specimen Verified: {assay['dosage_form']}, Integrity Score: {assay['hardware_integrity_score']}/100, "
        f"Delta-E*ab: {assay['optical_assay']['delta_e_ab']}, SHA-256: {assay['telemetry_hash'][:16]}...]"
    )

    new_query = ResearchQuery(
        id=query_id,
        user_id=current_user.id,
        drug_name=assay["resolved_drug_name"],
        normalized_drug_name=assay["resolved_drug_name"],
        pubchem_cid=assay["pubchem_cid"],
        chembl_id=assay["chembl_id"],
        research_question=hw_question,
        enable_clinical=payload.enable_clinical,
        enable_literature=payload.enable_literature,
        enable_patent=payload.enable_patent,
        enable_market=payload.enable_market,
        status=QueryStatus.QUEUED
    )
    db.add(new_query)
    await db.flush()

    scan_log = HardwareScanLog(
        id=scan_id,
        user_id=current_user.id,
        query_id=query_id,
        resolved_drug_name=assay["resolved_drug_name"],
        pubchem_cid=assay["pubchem_cid"],
        chembl_id=assay["chembl_id"],
        dosage_form=assay["dosage_form"],
        detected_imprint=assay["detected_imprint"],
        ndc_barcode=assay["ndc_barcode"],
        device_model=assay["device_model"],
        camera_resolution=assay["camera_resolution"],
        torch_enabled=assay["torch_enabled"],
        imu_gate_passed=assay["imu_telemetry"]["imu_gate_passed"],
        imu_stability_score=assay["imu_telemetry"]["imu_stability_score"],
        imu_jitter_ms2=assay["imu_telemetry"]["imu_jitter_ms2"],
        gyro_rms_rads=assay["imu_telemetry"]["gyro_rms_rads"],
        tilt_angle_deg=assay["imu_telemetry"]["tilt_angle_deg"],
        cie_l=assay["optical_assay"]["cie_lab_measured"]["L"],
        cie_a=assay["optical_assay"]["cie_lab_measured"]["a"],
        cie_b=assay["optical_assay"]["cie_lab_measured"]["b"],
        delta_e_ab=assay["optical_assay"]["delta_e_ab"],
        specular_gloss_index=assay["optical_assay"]["specular_gloss_index"],
        laplacian_sharpness=assay["optical_assay"]["laplacian_sharpness"],
        aspect_ratio=assay["optical_assay"]["aspect_ratio"],
        circularity=assay["optical_assay"]["circularity"],
        hardware_integrity_score=assay["hardware_integrity_score"],
        authenticity_status=assay["authenticity_status"],
        telemetry_hash=assay["telemetry_hash"],
        full_telemetry_json=assay,
        execution_time_ms=assay["execution_time_ms"]
    )
    db.add(scan_log)
    await db.commit()
    await db.refresh(scan_log)

    client_ip = request.client.host if request.client else None
    await record_audit_log(
        db=db,
        user_id=current_user.id,
        action="HARDWARE_TRIGGERED_RESEARCH_ANALYSIS",
        resource_type="QUERY",
        resource_id=query_id,
        ip_address=client_ip,
        details={
            "scan_id": scan_id,
            "drug_name": assay["resolved_drug_name"],
            "hardware_integrity_score": assay["hardware_integrity_score"],
            "telemetry_hash": assay["telemetry_hash"]
        }
    )

    background_tasks.add_task(
        run_master_agent_background,
        query_id=query_id,
        drug_name=assay["resolved_drug_name"],
        research_question=hw_question,
        enable_clinical=payload.enable_clinical,
        enable_literature=payload.enable_literature,
        enable_patent=payload.enable_patent,
        enable_market=payload.enable_market
    )

    return HardwareAssayResponse(
        scan_id=scan_id,
        query_id=query_id,
        created_at=scan_log.created_at,
        **assay
    )


@router.get("/scans")
async def list_hardware_scans(
    limit: int = 20,
    current_user: User = Depends(get_current_active_user),
    db: AsyncSession = Depends(get_db)
):
    """Retrieve recent mobile opto-inertial hardware specimen scan logs."""
    stmt = (
        select(HardwareScanLog)
        .where(HardwareScanLog.user_id == current_user.id)
        .order_by(desc(HardwareScanLog.created_at))
        .limit(limit)
    )
    res = await db.execute(stmt)
    rows = res.scalars().all()
    return [
        {
            "scan_id": r.id,
            "query_id": r.query_id,
            "resolved_drug_name": r.resolved_drug_name,
            "pubchem_cid": r.pubchem_cid,
            "dosage_form": r.dosage_form,
            "detected_imprint": r.detected_imprint,
            "device_model": r.device_model,
            "torch_enabled": r.torch_enabled,
            "imu_gate_passed": r.imu_gate_passed,
            "imu_jitter_ms2": r.imu_jitter_ms2,
            "tilt_angle_deg": r.tilt_angle_deg,
            "delta_e_ab": r.delta_e_ab,
            "specular_gloss_index": r.specular_gloss_index,
            "hardware_integrity_score": r.hardware_integrity_score,
            "authenticity_status": r.authenticity_status,
            "telemetry_hash": r.telemetry_hash,
            "created_at": r.created_at
        }
        for r in rows
    ]
