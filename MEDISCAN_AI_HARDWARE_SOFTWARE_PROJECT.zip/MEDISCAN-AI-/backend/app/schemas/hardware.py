from typing import Optional, Dict, Any, List
from datetime import datetime
from pydantic import BaseModel, Field, ConfigDict


class HardwareSensorPayload(BaseModel):
    """Input telemetry stream from the Mobile Opto-Inertial Hardware Unit."""
    drug_name: Optional[str] = Field(default=None, description="Optional drug label hint or OCR string")
    imprint_code: Optional[str] = Field(default=None, description="Debossed tablet imprint code captured optically")
    barcode_data: Optional[str] = Field(default=None, description="GS1 DataMatrix / NDC barcode string")
    device_model: Optional[str] = Field(default="Mobile CMOS + MEMS Inertial Sensor Unit")
    camera_resolution: Optional[str] = Field(default="1920x1080 Macro ROI")
    torch_enabled: bool = Field(default=True, description="Whether hardware LED flash strobe illumination is active")

    # 3-Axis MEMS Accelerometer (m/s^2) and Gyroscope (rad/s)
    accel_x: float = Field(default=0.04)
    accel_y: float = Field(default=-0.03)
    accel_z: float = Field(default=9.80)
    gyro_alpha: float = Field(default=0.01)
    gyro_beta: float = Field(default=0.01)
    gyro_gamma: float = Field(default=0.01)
    imu_jitter_ms2: Optional[float] = Field(default=None)

    # CMOS Optical Frame / Colorimetric Reflectance Values
    image_base64: Optional[str] = Field(default=None, description="Optional Base64 image frame from mobile CMOS sensor")
    rgb_r: Optional[float] = Field(default=None)
    rgb_g: Optional[float] = Field(default=None)
    rgb_b: Optional[float] = Field(default=None)
    specular_gloss_index: Optional[float] = Field(default=None)
    laplacian_sharpness: Optional[float] = Field(default=None)
    surface_homogeneity: Optional[float] = Field(default=None)
    aspect_ratio: Optional[float] = Field(default=None)
    circularity: Optional[float] = Field(default=None)

    # Optional Research Coupling Parameters
    research_question: Optional[str] = Field(
        default="Identify high-confidence therapeutic repurposing indications verified via mobile opto-inertial hardware assay."
    )
    enable_clinical: bool = True
    enable_literature: bool = True
    enable_patent: bool = True
    enable_market: bool = True


class HardwareAssayResponse(BaseModel):
    scan_id: str
    query_id: Optional[str] = None
    resolved_drug_name: str
    pubchem_cid: Optional[str] = None
    chembl_id: Optional[str] = None
    dosage_form: str
    coating_type: str
    bbb_permeability_class: str
    moisture_sensitivity: str
    detected_imprint: str
    ndc_barcode: str
    device_model: str
    camera_resolution: str
    torch_enabled: bool
    imu_telemetry: Dict[str, Any]
    optical_assay: Dict[str, Any]
    hardware_integrity_score: float
    authenticity_status: str
    telemetry_hash: str
    execution_time_ms: int
    created_at: datetime

    model_config = ConfigDict(from_attributes=True)
