from typing import Optional
from sqlalchemy import String, Float, Boolean, Integer, ForeignKey, JSON, Text
from sqlalchemy.orm import Mapped, mapped_column
from backend.app.database.base import Base, TimestampMixin


class HardwareScanLog(Base, TimestampMixin):
    """Persists physical mobile sensor telemetry and optical tablet assay records."""
    __tablename__ = "hardware_scan_logs"

    id: Mapped[str] = mapped_column(String(36), primary_key=True, index=True)
    user_id: Mapped[str] = mapped_column(String(36), ForeignKey("users.id", ondelete="CASCADE"), nullable=False, index=True)
    query_id: Mapped[Optional[str]] = mapped_column(String(36), ForeignKey("research_queries.id", ondelete="SET NULL"), nullable=True, index=True)

    # Resolved Compound Identity
    resolved_drug_name: Mapped[str] = mapped_column(String(255), nullable=False, index=True)
    pubchem_cid: Mapped[Optional[str]] = mapped_column(String(50), nullable=True)
    chembl_id: Mapped[Optional[str]] = mapped_column(String(50), nullable=True)
    dosage_form: Mapped[Optional[str]] = mapped_column(String(255), nullable=True)
    detected_imprint: Mapped[Optional[str]] = mapped_column(String(100), nullable=True)
    ndc_barcode: Mapped[Optional[str]] = mapped_column(String(100), nullable=True)

    # Mobile Hardware Sensor Parameters
    device_model: Mapped[str] = mapped_column(String(255), default="Smartphone Opto-Inertial Terminal", nullable=False)
    camera_resolution: Mapped[str] = mapped_column(String(100), default="1920x1080", nullable=False)
    torch_enabled: Mapped[bool] = mapped_column(Boolean, default=True, nullable=False)

    # 3-Axis MEMS IMU Telemetry
    imu_gate_passed: Mapped[bool] = mapped_column(Boolean, default=True, nullable=False)
    imu_stability_score: Mapped[float] = mapped_column(Float, default=95.0, nullable=False)
    imu_jitter_ms2: Mapped[float] = mapped_column(Float, default=0.05, nullable=False)
    gyro_rms_rads: Mapped[float] = mapped_column(Float, default=0.02, nullable=False)
    tilt_angle_deg: Mapped[float] = mapped_column(Float, default=2.5, nullable=False)

    # CMOS Optical & Colorimetric CIE L*a*b* Assay
    cie_l: Mapped[float] = mapped_column(Float, default=94.0, nullable=False)
    cie_a: Mapped[float] = mapped_column(Float, default=-0.4, nullable=False)
    cie_b: Mapped[float] = mapped_column(Float, default=1.8, nullable=False)
    delta_e_ab: Mapped[float] = mapped_column(Float, default=0.8, nullable=False)
    specular_gloss_index: Mapped[float] = mapped_column(Float, default=0.68, nullable=False)
    laplacian_sharpness: Mapped[float] = mapped_column(Float, default=85.0, nullable=False)
    aspect_ratio: Mapped[float] = mapped_column(Float, default=1.85, nullable=False)
    circularity: Mapped[float] = mapped_column(Float, default=0.78, nullable=False)

    # Overall Hardware Integrity Output
    hardware_integrity_score: Mapped[float] = mapped_column(Float, default=94.0, nullable=False)
    authenticity_status: Mapped[str] = mapped_column(String(100), nullable=False)
    telemetry_hash: Mapped[str] = mapped_column(String(64), nullable=False, index=True)
    full_telemetry_json: Mapped[Optional[dict]] = mapped_column(JSON, nullable=True)
    execution_time_ms: Mapped[int] = mapped_column(Integer, default=12, nullable=False)
