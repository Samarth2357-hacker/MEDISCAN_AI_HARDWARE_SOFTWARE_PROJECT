"""
MediScan AI - Mobile Opto-Inertial Hardware Sensor & Physical Assay Subsystem.
Integrates Smartphone CMOS Image Sensor, Programmable LED Flash Strobe,
and 3-Axis MEMS Inertial Measurement Unit (Accelerometer + Gyroscope)
with Multi-Agent Drug Repurposing Intelligence.
"""
from backend.app.hardware.sensor_engine import hardware_sensor_engine, MobileHardwareSensorEngine

__all__ = ["hardware_sensor_engine", "MobileHardwareSensorEngine"]
